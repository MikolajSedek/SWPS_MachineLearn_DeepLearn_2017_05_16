source activate py3deep
jupyter notebook
