source activate py2ml
jupyter notebook
